package com.spring.biz.commentSet;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.biz.comments.CommentsVO;

@Service("commentSetService")
public class CommentSetServiceImpl implements CommentSetService{

	@Autowired
	private CommentSetDAO csDAO;
	
	@Override
	public List<CommentSet> selectAll(CommentsVO cVO, int count) {
		return csDAO.selectAll(cVO, count);
	}

}
