package com.spring.view.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.biz.board.BoardService;
import com.spring.biz.board.BoardVO;
import com.spring.biz.commentSet.CommentSet;
import com.spring.biz.commentSet.CommentSetService;
import com.spring.biz.comments.CommentsService;
import com.spring.biz.comments.CommentsVO;
import com.spring.biz.recommend.RecommendService;
import com.spring.biz.recommend.RecommendVO;
import com.spring.biz.reply.ReplyService;
import com.spring.biz.reply.ReplyVO;

@Controller
public class Notice {

	@Autowired
	private BoardService boardService;
	
	@Autowired
	private CommentsService commentsService;
	
	@Autowired
	private ReplyService replyService;

	@Autowired
	private RecommendService recommendService;

	@RequestMapping(value = "/noticeListPage.do")
	public String notcieListPage(BoardVO  bVO, HttpServletRequest request) {
		System.out.println("로그: Notice: noticeListPage() ");

		ArrayList<BoardVO> currentPageNotices = new ArrayList<BoardVO>();

		// 페이지 파라미터를 가져와서 bVO에 설정합니다.
		if(request.getParameter("page") != null) {
			bVO.setPage(Integer.parseInt(request.getParameter("page")));
		} else {
			bVO.setPage(1);
		}
		int currentPage = bVO.getPage();

		// 현재 페이지 정보를 request에 저장합니다.
		request.setAttribute("currentPagent", currentPage);

		// 공지사항 목록을 조회하기 위해 bVO에 설정합니다.
		bVO.setSelect("커뮤니티");
		bVO.setCategory(0);

		// 전체 공지사항 목록을 조회합니다.
		List<BoardVO> bdatas = new ArrayList<BoardVO>();

		bdatas = boardService.selectAll(bVO);

		request.setAttribute("bdatasnt", bdatas);

		// 전체 공지사항 개수를 구합니다.
		int totalPosts = bdatas.size();

		// 한 페이지에 보여줄 공지사항 개수를 설정합니다. (10개씩 표시)
		int postsPerPage = 10;

		// 현재 페이지에 해당하는 공지사항의 시작 인덱스와 끝 인덱스를 계산합니다.
		int startIdx = (currentPage - 1) * postsPerPage;
		int endIdx = Math.min(currentPage * postsPerPage, totalPosts);

		// 현재 페이지에 해당하는 공지사항만 currentPageNotices에 추가합니다.
		for (int i = startIdx; i < endIdx; i++) {
			currentPageNotices.add(bdatas.get(i));
		} 	

		// 현재 페이지의 공지사항 목록을 request에 저장합니다.
		request.setAttribute("currentPageNotices", currentPageNotices);

		// forward 객체를 설정하여 noticeListPage.jsp로 포워딩합니다.
		return "noticeListPage.jsp";
	}

	@RequestMapping(value = "/noticeDetailPage.do")
	public String noticeDetailPage(BoardVO bVO, CommentsVO cVO, RecommendVO rcVO, HttpSession session, HttpServletRequest request) {
		System.out.println("로그: Notice: noticeDetailPage() ");

		rcVO.setMid((String)session.getAttribute("mid"));

		rcVO = recommendService.selectOne(rcVO);

		if(rcVO != null) {
			request.setAttribute("recommend", 1);
		}
		else {
			request.setAttribute("recommend", 0);
		}

		List<CommentsVO> cdatas = commentsService.selectAll(null);

		List<CommentsVO> comments = new ArrayList<CommentsVO>();

		List<ReplyVO> rdatas = replyService.selectAll(null);

		List<ReplyVO> replies = new ArrayList<ReplyVO>();

		for(int i = 0; i < cdatas.size(); i++) {
			if(bVO.getBoardNum() == cdatas.get(i).getBoardNum()) {
				comments.add(cdatas.get(i));
			}
			for(int j = 0; j < rdatas.size(); i++) {
				if(cdatas.get(i).getCommentsNum() == rdatas.get(j).getCommentsNum()) {
					replies.add(rdatas.get(j));
				}
			}
		}
		
		bVO = boardService.selectOne(bVO);

		// 게시글 데이터가 조회되었을 경우, 게시글 정보를 JSP 페이지에서 사용할 수 있도록 request에 저장합니다.
		if(bVO != null) {
			request.setAttribute("bdata", bVO);
			request.setAttribute("cdatas", comments);
			request.setAttribute("rdatas", replies);

			return "boardDetailPage.jsp";
		}
		else {
			request.setAttribute("title", "요청실패..");
			request.setAttribute("text", "다시한번 확인해주세요.." );
			request.setAttribute("icon", "warning" );

			return "goback.jsp";
		}
	}

	@RequestMapping(value = "/insertNoticePage.do")
	public String insertNoticePage() {
		System.out.println("로그: Notice: insertNoticePage() ");

		return "redirect:insertNoticePage.jsp";
	}

	@RequestMapping(value = "/insertNotice.do")
	public String insertNotice(BoardVO bVO, HttpSession session, Model model) {
		System.out.println("로그: Notice: insertNotice() ");

		bVO.setMid((String)session.getAttribute("mid"));

		boolean flag = boardService.insert(bVO);

		if(flag) {
			return "noticeListPage.do";
		} else {
			model.addAttribute("title", "공지사항작성실패.." );
			model.addAttribute("text", "다시한번 확인해주세요.." );
			model.addAttribute("icon", "warning" );

			return "goback.jsp";
		}
	}

	@RequestMapping(value = "/updateNoticePage.do")
	public String updateNoticePage(BoardVO bVO, Model model) {
		System.out.println("로그: Notice: updateNoticePage() ");

		bVO = boardService.selectOne(bVO);

		if (bVO != null) {
			model.addAttribute("bdata", bVO);

			return "updateNoticePage.jsp?boardNum=" + bVO.getBoardNum();
		}
		else {
			model.addAttribute("title", "요청실패.." );
			model.addAttribute("text", "다시한번 확인해주세요.." );
			model.addAttribute("icon", "warning" );

			return "goback.jsp";
		}

	}

	@RequestMapping(value = "/updateNotice.do")
	public String updateNotice(BoardVO bVO, Model model) {
		System.out.println("로그: Notice: updateNotice() ");

		bVO.setSelect("글수정");

		boolean flag = boardService.update(bVO);

		if (flag) {
			return "noticeDetailPage.do?boardNum=" + bVO.getBoardNum();
		} else {
			model.addAttribute("title", "공지사항 수정 실패..");
			model.addAttribute("text", "다시한번 확인해주세요..");
			model.addAttribute("icon", "warning");

			return "goback.jsp";
		}
	}

	@RequestMapping(value = "/deleteNotice.do")
	public String deleteNotice(BoardVO bVO, Model model) {
		System.out.println("로그: Notice: deleteNotice() ");

		boolean flag = boardService.delete(bVO);

		if (flag) {
			return "noticeListPage.do";
		}
		else {
			// 삭제 실패 메시지를 설정하기 위해 필요한 데이터를 request에 저장합니다.
			model.addAttribute("title", "공지사항삭제실패..");
			model.addAttribute("text", "다시 한번 확인해주세요..");
			model.addAttribute("icon", "warning");

			return "goback.jsp";
		}
	}
}
