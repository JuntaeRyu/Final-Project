package com.spring.biz.prohibit;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository("prohibitDAO")
public class ProhibitDAO2 {
	// SQL 쿼리문
	private final String sql_INSERT = "INSERT INTO PROHIBIT (MID,NUM) VALUES ( ? , ? )";
	private final String sql_SELECTALL = "SELECT PROHIBITNUM,MID,NUM FROM PROHIBIT WHERE NUM=?";
	private final String sql_SELECTONE = "SELECT PROHIBITNUM,MID,NUM FROM PROHIBIT WHERE MID=? AND NUM=?";
	private final String sql_DELETE = "DELETE FROM PROHIBIT WHERE PROHIBITNUM=?";

	// JDBC(자바 데이터베이스 커넥트) 도구
	@Autowired
	private JdbcTemplate jdbcTemplate;

	public boolean insert(ProhibitVO pVO) { // DB에 객체정보 저장

		// 쿼리문 수정 및 실행 후 결과를 저장
		int result = jdbcTemplate.update(sql_INSERT, pVO.getMid(), pVO.getFknum());

		// 검색 결과 리턴
		if (result <= 0) {
			return false; // 저장 실패
		}
		return true;
	} // insert

	public List<ProhibitVO> selectAll(ProhibitVO pVO) { // 목록 검색

		// 쿼리문 수정할 정보 저장
		Object[] args = { pVO.getFknum() };
		
		// 쿼리문 수정 및 실행 후 결과 리턴
		return jdbcTemplate.query(sql_SELECTALL, args, new ProhibitRowMapper());
	}

	public ProhibitVO selectOne(ProhibitVO pVO) { // 하나의 객체 정보 검색

		// 쿼리문 수정할 정보 저장
		Object[] args = { pVO.getMid(), pVO.getFknum() };
		
		// 쿼리문 수정 및 실행 후 결과 리턴
		return jdbcTemplate.queryForObject(sql_SELECTONE, args, new ProhibitRowMapper());
		
	}

	public boolean update(ProhibitVO pVO) {
		return false;
	}

	public boolean delete(ProhibitVO pVO) {

		// 쿼리문 수정 및 실행 후 결과를 저장
		int result = jdbcTemplate.update(sql_DELETE, pVO.getProhibitNum());

		// 성공 리턴
		if (result <= 0) {
			return false;
		}
		return true;
	}
}

class ProhibitRowMapper implements RowMapper<ProhibitVO> {

	@Override
	public ProhibitVO mapRow(ResultSet rs, int rowNum) throws SQLException {
		ProhibitVO pdata = new ProhibitVO();
		pdata.setProhibitNum(rs.getInt("PROHIBITNUM"));
		pdata.setMid(rs.getString("MID"));
		pdata.setFknum(rs.getInt("NUM"));
		return pdata;
	}

}
