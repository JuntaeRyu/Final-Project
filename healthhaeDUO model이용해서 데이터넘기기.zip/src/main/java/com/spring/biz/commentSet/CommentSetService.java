package com.spring.biz.commentSet;

import java.util.List;

import com.spring.biz.comments.CommentsVO;

public interface CommentSetService {
	public List<CommentSet> selectAll(CommentsVO cVO, int count);
}
