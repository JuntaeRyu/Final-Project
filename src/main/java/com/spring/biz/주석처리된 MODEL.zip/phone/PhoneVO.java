package com.spring.biz.phone;

public class PhoneVO {
	
}
