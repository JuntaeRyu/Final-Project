package com.spring.biz.role;

public class RoleDAO {

}
