package com.spring.biz.role;

public class RoleVO {
	private int roleNum;
	private String role;
	
	
}
